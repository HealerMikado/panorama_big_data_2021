from cython_code.get_max_python import get_max_temp_per_year

if __name__=="__main__" :
    get_max_temp_per_year("ncdc_data")